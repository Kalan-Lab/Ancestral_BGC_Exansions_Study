import os
import sys
from ete3 import Tree

t = Tree(sys.argv[1])

inid = 1
for node in t.traverse('postorder'):
    if not node.is_leaf():
        node.name = 'Node_' + str(inid)
        inid+= 1

t.write(outfile=sys.argv[2],format=1)
