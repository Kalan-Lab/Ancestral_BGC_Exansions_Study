Note, comprehensive FASTA files containing all suspect PKS and NRPS proteins were split into blocks of 500 to get NCBI webservers to accept them. 
